

public class ths_CIM10 {

	private String codeCIM10;
	private String libelleCIM10;
	/**
	 * @return the codeCIM10
	 */
	public String getCodeCIM10() {
		return codeCIM10;
	}
	/**
	 * @param codeCIM10 the codeCIM10 to set
	 */
	public void setCodeCIM10(String codeCIM10) {
		this.codeCIM10 = codeCIM10;
	}
	/**
	 * @return the libelleCIM10
	 */
	public String getLibelleCIM10() {
		return libelleCIM10;
	}
	/**
	 * @param libelleCIM10 the libelleCIM10 to set
	 */
	public void setLibelleCIM10(String libelleCIM10) {
		this.libelleCIM10 = libelleCIM10;
	}
	
	
}
