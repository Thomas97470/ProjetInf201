

import java.util.ArrayList;
import java.util.Date;

public class Hospitalisation {

		private int numHospitalisation;
		private Date dateEntree;
		private Date dateSortie;
		private ArrayList<Patient> listnumPatient = new ArrayList <>();
		private ArrayList<Acte> listnumActe = new ArrayList <>();
		private ArrayList<Diagnostic> listnumDiagnostic = new ArrayList <>();

		
		/**
		 * @return the numHospitalisation
		 */
		public int getNumHospitalisation() {
			return numHospitalisation;
		}

		/**
		 * @param numHospitalisation the numHospitalisation to set
		 */
		public void setNumHospitalisation(int numHospitalisation) {
			this.numHospitalisation = numHospitalisation;
		}

		/**
		 * @return the dateEntree
		 */
		public Date getDateEntree() {
			return dateEntree;
		}

		/**
		 * @param dateEntree the dateEntree to set
		 */
		public void setDateEntree(Date dateEntree) {
			this.dateEntree = dateEntree;
		}

		/**
		 * @return the dateSortie
		 */
		public Date getDateSortie() {
			return dateSortie;
		}

		/**
		 * @param dateSortie the dateSortie to set
		 */
		public void setDateSortie(Date dateSortie) {
			this.dateSortie = dateSortie;
		}

		/**
		 * @return the listnumPatient
		 */
		public ArrayList<Patient> getListnumPatient() {
			return listnumPatient;
		}

		/**
		 * @param listnumPatient the listnumPatient to set
		 */
		public void setListnumPatient(ArrayList<Patient> listnumPatient) {
			this.listnumPatient = listnumPatient;
		}

		/**
		 * @return the listnumActe
		 */
		public ArrayList<Acte> getListnumActe() {
			return listnumActe;
		}

		/**
		 * @param listnumActe the listnumActe to set
		 */
		public void setListnumActe(ArrayList<Acte> listnumActe) {
			this.listnumActe = listnumActe;
		}

		/**
		 * @return the listnumDiagnostic
		 */
		public ArrayList<Diagnostic> getListnumDiagnostic() {
			return listnumDiagnostic;
		}

		/**
		 * @param listnumDiagnostic the listnumDiagnostic to set
		 */
		public void setListnumDiagnostic(ArrayList<Diagnostic> listnumDiagnostic) {
			this.listnumDiagnostic = listnumDiagnostic;
		}

		/**
		 * Constructeur : cr�ation d'une nouvelle hospitalisation.
		 * @param numHospitalisation
		 * @param i 
		 * @param dateEntree
		 * @param dateSortie
		 */
		public Hospitalisation(int numHospitalisation, int i, Date dateEntree, Date dateSortie) {
			super();
			this.numHospitalisation = numHospitalisation;
			this.dateEntree = dateEntree;
			this.dateSortie = dateSortie;
		}

		public Hospitalisation() {
			// TODO Auto-generated constructor stub
		}
		
		//ajout ou suppression d'un diagnostique ou d'un acte � un num�ro d'hospitalisation
		public void ajoutdiagnostic(Diagnostic d) 
			{
			this.listnumDiagnostic.add(d);
			}
	
		public void suppressiondiagnostic(Diagnostic d)
			{
			this.listnumDiagnostic.remove(d);
			}
		
		public void ajoutacte(Acte a)
			{
			this.listnumActe.add(a);
			}
		
		public void suppressionacte(Acte a)
			{
			this.listnumActe.remove(a);
			}
			
}	

