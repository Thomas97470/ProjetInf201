

public class ths_CCAM {
	
	private String codeCCAM;
	private String libelleCCAM;
	/**
	 * @return the codeCCAM
	 */
	public String getCodeCCAM() {
		return codeCCAM;
	}
	/**
	 * @param codeCCAM the codeCCAM to set
	 */
	public void setCodeCCAM(String codeCCAM) {
		this.codeCCAM = codeCCAM;
	}
	/**
	 * @return the libelleCCAM
	 */
	public String getLibelleCCAM() {
		return libelleCCAM;
	}
	/**
	 * @param libelleCCAM the libelleCCAM to set
	 */
	public void setLibelleCCAM(String libelleCCAM) {
		this.libelleCCAM = libelleCCAM;
	}
	
	
	
}
