

import java.util.ArrayList;

public class Diagnostic {

	private int numDiagnostic;
	private ArrayList <Hospitalisation> ListnumHospitalisation = new ArrayList <>();
	private ArrayList <ths_CIM10> ListcodeCIM10 = new ArrayList <>();
	private int dgRang;
	private int dgType;
	/**
	 * @return the numDiagnostic
	 */
	public int getNumDiagnostic() {
		return numDiagnostic;
	}
	/**
	 * @param numDiagnostic the numDiagnostic to set
	 */
	public void setNumDiagnostic(int numDiagnostic) {
		this.numDiagnostic = numDiagnostic;
	}
	/**
	 * @return the listnumHospitalisation
	 */
	public ArrayList<Hospitalisation> getListnumHospitalisation() {
		return ListnumHospitalisation;
	}
	/**
	 * @param listnumHospitalisation the listnumHospitalisation to set
	 */
	public void setListnumHospitalisation(ArrayList<Hospitalisation> listnumHospitalisation) {
		ListnumHospitalisation = listnumHospitalisation;
	}
	/**
	 * @return the listcodeCIM10
	 */
	public ArrayList<ths_CIM10> getListcodeCIM10() {
		return ListcodeCIM10;
	}
	/**
	 * @param listcodeCIM10 the listcodeCIM10 to set
	 */
	public void setListcodeCIM10(ArrayList<ths_CIM10> listcodeCIM10) {
		ListcodeCIM10 = listcodeCIM10;
	}
	/**
	 * @return the dgRang
	 */
	public int getDgRang() {
		return dgRang;
	}
	/**
	 * @param dgRang the dgRang to set
	 */
	public void setDgRang(int dgRang) {
		this.dgRang = dgRang;
	}
	/**
	 * @return the dgType
	 */
	public int getDgType() {
		return dgType;
	}
	/**
	 * @param dgType the dgType to set
	 */
	public void setDgType(int dgType) {
		this.dgType = dgType;
	}
	/**
	 * constructeur 
	 * @param numDiagnostic
	 * @param listnumHospitalisation
	 * @param listcodeCIM10
	 * @param dgRang
	 * @param dgType
	 */
	public Diagnostic(int numDiagnostic, ArrayList<Hospitalisation> listnumHospitalisation,
			ArrayList<ths_CIM10> listcodeCIM10, int dgRang, int dgType) {
		super();
		this.numDiagnostic = numDiagnostic;
		this.dgRang = dgRang;
		this.dgType = dgType;
	}
	
}
