

import java.util.ArrayList;
import java.util.Date;

public class Acte {

	private int numActe;
	private ArrayList <ths_CCAM> ListcodeCCAM = new ArrayList <>(); 
	private Date dateActe;
	private ArrayList <Hospitalisation> ListnumHospitalisation = new ArrayList <>();
	private boolean anesthesie;
	/**
	 * @return the numActe
	 */
	public int getNumActe() {
		return numActe;
	}
	/**
	 * @param numActe the numActe to set
	 */
	public void setNumActe(int numActe) {
		this.numActe = numActe;
	}
	/**
	 * @return the listcodeCCAM
	 */
	public ArrayList<ths_CCAM> getListcodeCCAM() {
		return ListcodeCCAM;
	}
	/**
	 * @param listcodeCCAM the listcodeCCAM to set
	 */
	public void setListcodeCCAM(ArrayList<ths_CCAM> listcodeCCAM) {
		ListcodeCCAM = listcodeCCAM;
	}
	/**
	 * @return the dateActe
	 */
	public Date getDateActe() {
		return dateActe;
	}
	/**
	 * @param dateActe the dateActe to set
	 */
	public void setDateActe(Date dateActe) {
		this.dateActe = dateActe;
	}
	/**
	 * @return the listnumHospitalisation
	 */
	public ArrayList<Hospitalisation> getListnumHospitalisation() {
		return ListnumHospitalisation;
	}
	/**
	 * @param listnumHospitalisation the listnumHospitalisation to set
	 */
	public void setListnumHospitalisation(ArrayList<Hospitalisation> listnumHospitalisation) {
		ListnumHospitalisation = listnumHospitalisation;
	}
	/**
	 * @return the anesthesie
	 */
	public boolean getAnesthesie() {
		return anesthesie;
	}
	/**
	 * @param anesthesie the anesthesie to set
	 */
	public void setAnesthesie(boolean anesthesie) {
		this.anesthesie = anesthesie;
	}
	/**
	 * @param numActe
	 * @param listcodeCCAM
	 * @param dateActe
	 * @param listnumHospitalisation
	 * @param anesthesie
	 */
	public Acte(int numActe, ArrayList<ths_CCAM> listcodeCCAM, Date dateActe,
			ArrayList<Hospitalisation> listnumHospitalisation, boolean anesthesie) {
		super();
		this.numActe = numActe;
		ListcodeCCAM = listcodeCCAM;
		this.dateActe = dateActe;
		ListnumHospitalisation = listnumHospitalisation;
		this.anesthesie = anesthesie;
	}
	public Acte() {
		// TODO Auto-generated constructor stub
	}
	
	
 }
