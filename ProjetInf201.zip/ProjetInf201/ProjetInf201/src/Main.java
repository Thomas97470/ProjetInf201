import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class Main {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	@SuppressWarnings("resource")
	Scanner sc = new Scanner(System.in);
	char reponse = ' ';
		
		//URL du serveur o� est situ� la base de donn�e 
        String url = "jdbc:mysql://localhost/projetinf201";
        //utilisateur par d�faut
        String user = "root";
        //mot de passe d�sactiv�
        String password = "";

        Connection connexion = null;
        
        try
        {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection con = DriverManager.getConnection(url, user, password);

            java.sql.Statement stt = con.createStatement();
            //stt.execute("USE bdpatient");
do {           
            System.out.println("Base connect�e,");
            System.out.println("Bienvenue.");
            
            System.out.println("\n--------------------------MENU---------------------------");

            System.out.println("\nVeuillez saisir le num�ro de la requ�te souhait�e : ");
            System.out.println("1 - Voir les informations patient");
            System.out.println("2 - Voir la liste des hospitalisation patient");
            System.out.println("3 - Voir le nombre d'actes par num�ro d'hospitalisation");
            System.out.println("4 - voir un diagnostic patient");
            System.out.println("5 - Cr�ation d'un nouveau patient");
            
            //permet de s�lectionner une des 4 choix pr�sent�s dans le menu
            String choix = sc.nextLine();
            //switch : �viter la r�p�tition des if/else
            switch(choix) 
            	{
              case "1":
            	  //permet d'entrer dans une boucle et d'y rester tant que la r�ponse n'est pas 'N'. do permet d'effectuer la requ�te au moins une fois 
              	  do {
            		  int i = 0;
            		  System.out.println("\nVeuillez saisir un num�ro de patient");
            		  i = sc.nextInt();
            		  sc.nextLine();
            		  ResultSet pat = stt.executeQuery("SELECT * "
            				  						+ "FROM tab_patient "
                  								    + "WHERE NumPatient='"+i+"'");
            		  while (pat.next()) {
            			  	System.out.println("Num�ro de patient : " + pat.getInt(1) + "\nNom : " + pat.getString(5) 
            			  	                 + "	Pr�nom : " + pat.getString(4) + "\nDate de Naissance : " + pat.getDate(3) 
            			  	                 + "\nSexe(1:Homme, 2:Femme) : " + pat.getInt(2));  
            		  				     } 
            		  
            		  do { 
            			  System.out.println("\nVoulez-vous s�lectionner un nouveau patient ? (O/N)");
            			  reponse = sc.nextLine().charAt(0);
        				 } while (reponse != 'O' && reponse != 'N');
            	     } while (reponse == 'O'); 
              	break;
              
                 
              case "2": 
            	 do {	
            	  	int i = 0;
            	  	System.out.print("\nVeuillez saisir un num�ro de patient");
            	  	i = sc.nextInt();
            	  	sc.nextLine();
            	  	System.out.println("\nLe patient num�ro " + i + " a comme s�jour(s) le(s) num�ro(s) d'hospitalisation :");
            	  	ResultSet res2 = stt.executeQuery("SELECT * "
            	  									+ "FROM tab_hospitalisation "
            	  									+ "WHERE NumPatient = '"+i+"'");
            	  			
            	  	while (res2.next()) {
            	  		System.out.println("\nN� " + res2.getInt(1) + "\nDate d'entr�e : " + res2.getDate(3) + "\nDate de sortie : " + res2.getDate(4));
            	  						}
            	  	
            	  	do { 
        			  System.out.println("\nVoulez-vous s�lectionner un nouveau patient ? (O/N)");
        			  reponse = sc.nextLine().charAt(0);
            	  	   } while (reponse != 'O' && reponse != 'N');
        	        } while (reponse == 'O');             	  	
                 break;
             
                 
              case "3":
            	  System.out.println("-----------------------------------------");
            	  ResultSet res3 = stt.executeQuery("SELECT DISTINCT h.NumHospitalisation, count(NumActe) AS NbrActe " //Attention a l'espace entre le dernier mot et les guillemets
            	  									+ "FROM tab_hospitalisation AS h, tab_acte AS a "
            	  									+ "WHERE h.NumHospitalisation = a.NumHopitalisation "
            	  									+ "GROUP BY h.NumHospitalisation");
            	  									
            	  	while (res3.next()) {
            	  		
            	  		System.out.println("| N� | " + res3.getInt(1) + " | Nombre d'actes | " + res3.getInt(2));
            	  		System.out.println("-----------------------------------------");
            	  						}
            	  break;
            	
              case "4":
            	  do {
          	  	  	int i = 0;
          	  	  	System.out.print("\nVeuillez saisir un num�ro de patient");
          	  	  	i = sc.nextInt();
          	  	  	sc.nextLine();
          	  	  	ResultSet res4 = stt.executeQuery("SELECT DISTINCT Nom, Prenom, p.NumPatient, h.NumHospitalisation, d.CodeCIM10, LibelleCIM10, DateEntree "
          	  	  									 +"FROM tab_patient AS p, tab_hospitalisation AS h, tab_diagnostic AS d, ths_cim10 AS c "
            			  						     +"WHERE p.NumPatient = h.NumPatient "
            			  						     +"AND h.NumHospitalisation = d.NumHospitalisation "
            			  						     +"AND d.CodeCIM10 = c.CodeCIM10 "
            			  						     +"AND p.NumPatient = '"+i+"' ");
            	  
          	  	  		while(res4.next()) {
          	  	  			System.out.println("\nLe code hospitalisation " + res4.getInt(4) + " Date d'entr�e" + res4.getDate(7) + "\ncorrespondant au patient " + res4.getString(1) + " " + res4.getString(2)
          	  	  							 + " num�ro " + res4.getInt(3) + "\na eu pour diagnostic un/une " + res4.getString(6) + "\nCode CIM10 " + res4.getString(5));
            	  					       }
                	  	do { 
              			  System.out.println("\nVoulez-vous s�lectionner un nouveau patient ? (O/N)");
              			  reponse = sc.nextLine().charAt(0);
                  	  	   } while (reponse != 'O' && reponse != 'N');
            	   	}while (reponse =='O');
            	  break;
             	  
              case "5":
            	  do {
            	  int i = 0;
            	  int s = 0;
            	  String d;
            	  String p;
            	  String n;
            	  System.out.println("Veuillez saisir un identifiant patient � 6 chiffres");
        	  	  	i = sc.nextInt();
        	  	  	sc.nextLine();
        	  	  System.out.println("Veuillez indiquer le sexe du patient (1 : Homme, 2 : Femme)");	
        	  	  	s = sc.nextInt();
        	  	  	sc.nextLine();
        	  	  System.out.println("Veuillez saisir la date de naissance du patient dd/mm/yyyy");
        	  	  	d = sc.nextLine();
        	  	  	java.util.Date d1= new SimpleDateFormat("dd/MM/yyyy").parse(d);
        	  	  System.out.println(d+"\t"+d1);
        	  	  
        	  	  System.out.println("Veuillez entrer le pr�nom du patient");	
        	  	  	p = sc.nextLine();
        	  	  System.out.println("Veuillez entrer le nom du patient");	
        	  	  	n = sc.nextLine();
       	  	  	
        	  	  Patient pat= new Patient(i,s,d1,p,n);
        	  	  System.out.println("\nNouveau Patient :");
        	  	  System.out.println("\n" + pat.toString());
        	  	  		do { 
        	  	  			System.out.println("\nVoulez-vous cr�er un nouveau patient ? (O/N)");
        	  	  			reponse = sc.nextLine().charAt(0);
        	  	  			} while (reponse != 'O' && reponse != 'N');
            	   }while (reponse == 'O');
        	  	  break;
        	  	  
              default:
                System.out.println("\nMerci de saisir un num�ro de requ�te valide");
            	}
            
  System.out.println("\nVoulez vous saisir une nouvelle requ�te ? (O/N)");
  reponse = sc.nextLine().charAt(0);
} while (reponse == 'O');
System.out.println("\nMerci d'avoir utilis� ce programme"); 
        }
        catch (Exception e)
        	{
            e.printStackTrace();
        	} finally 
        		{
            	if (connexion != null)
            		try {
            			connexion.close();
            			} 
            			catch (SQLException ignore) {
            										}
            	}	
	}
}
