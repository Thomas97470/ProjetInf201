

import java.util.ArrayList;
import java.util.Date;

public class Patient {
	//description des colonnes de la table tab_patient
	private int numPatient;
	private int sexe;
	private Date dateNaissance;
	private String prenom;
	private String nom;
	private ArrayList<Hospitalisation> listHospitalisation = new ArrayList<>();
	/**
	 * @return the numPatient
	 */
	public int getNumPatient() {
		return numPatient;
	}
	/**
	 * @param numPatient the numPatient to set
	 */
	public void setNumPatient(int numPatient) {
		this.numPatient = numPatient;
	}
	/**
	 * @return the sexe
	 */
	public int getSexe() {
		return sexe;
	}
	/**
	 * @param sexe the sexe to set
	 */
	public void setSexe(int sexe) {
		this.sexe = sexe;
	}
	/**
	 * @return the dateNaissance
	 */
	public Date getDateNaissance() {
		return dateNaissance;
	}
	/**
	 * @param dateNaissance the dateNaissance to set
	 */
	public void setDateNaissance(Date dateNaissance) {
		this.dateNaissance = dateNaissance;
	}
	/**
	 * @return the prenom
	 */
	public String getPrenom() {
		return prenom;
	}
	/**
	 * @param prenom the prenom to set
	 */
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	/**
	 * @return the nom
	 */
	public String getNom() {
		return nom;
	}
	/**
	 * @param nom the nom to set
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}
	/**
	 * @return the listHospitalisation. Permet de r�cup�rer les informations de la table hospitalisation. 
	 */
	public ArrayList<Hospitalisation> getListHospitalisation() {
		return listHospitalisation;
	}
	/**
	 * @param listHospitalisation the listHospitalisation to set
	 */
	public void setListHospitalisation(ArrayList<Hospitalisation> listHospitalisation) {
		this.listHospitalisation = listHospitalisation;
	}
	/**
	 * COnstructeur patient 1
	 * @param numPatient
	 * @param sexe
	 * @param dateNaissance
	 * @param prenom
	 * @param nom
	 * @param listHospitalisation
	 */
	public Patient(int numPatient, int sexe, Date dateNaissance, String prenom, String nom,
			ArrayList<Hospitalisation> listHospitalisation) 
		{
		super();
		this.numPatient = numPatient;
		this.sexe = sexe;
		this.dateNaissance = dateNaissance;
		this.prenom = prenom;
		this.nom = nom;
		this.listHospitalisation = listHospitalisation;	
		}
	/**
	 * constructeur patient 2
	 * @param numPatient
	 * @param sexe
	 * @param dateNaissance
	 * @param prenom
	 * @param nom
	 */
	public Patient(int numPatient, int sexe, Date dateNaissance, String prenom, String nom) 
		{
		super();
		this.numPatient = numPatient;
		this.sexe = sexe;
		this.dateNaissance = dateNaissance;
		this.prenom = prenom;
		this.nom = nom;
		}
	
	public Patient() {}
	
	//cr�ation d'un patient, ajout/suppression d'une entr�e hospitalisation pour un patient
	public String toString ()
		{
		return "NumPatient: " + this.getNumPatient() + "\nNom: " + this.getNom() + " Prenom: " + this.getPrenom() + "\nSexe :" + this.getSexe() + "\nDateNaissance : " + this.getDateNaissance();
		}
	
	public void ajouthospitalisation(Hospitalisation h) 
		{
		this.listHospitalisation.add(h);
		}
	
	public void suppressionhospitalisation(Hospitalisation h)
		{
		this.listHospitalisation.remove(h);
		}
}
	

